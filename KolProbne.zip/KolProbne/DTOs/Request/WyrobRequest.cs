﻿namespace KolProbne.DTOs.Request
{
    public class WyrobRequest
    {
        public int Ilosc { get; set; }
        public string Wyrob { get; set; }
        public string Uwagi { get; set; }
    }
}
